package ch.hslu.cobau.minij.generation;

public interface Optimizer {
    String optimize(String code);
}
